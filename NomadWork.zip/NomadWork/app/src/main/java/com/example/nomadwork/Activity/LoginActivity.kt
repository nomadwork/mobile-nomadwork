package com.example.nomadwork.Activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.Fragment
import butterknife.BindView
import butterknife.ButterKnife
import butterknife.OnClick
import com.example.nomadwork.BuildConfig
import com.example.nomadwork.Fragments.LoginFragment
import com.example.nomadwork.R
import kotlinx.android.synthetic.main.fragment_login.*
import java.util.*

enum class LoginStep {
    SINGIN, NEWUSER
}

class LoginActivity : AppCompatActivity() {
    companion object {
        const val TAG = "LoginActivity"
    }

    private var currentLoginView = LoginStep.SINGIN
    private var _loginFragment: LoginFragment? = null


    private val loginFragment: LoginFragment
        get() {
            if(_loginFragment == null){
                _loginFragment = LoginFragment()
            }
            return _loginFragment!!
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        ButterKnife.bind(this)

        doReplaceFragment(currentLoginView)

        supportFragmentManager.addOnBackStackChangedListener { invalidateOptionsMenu() }
    }

    override fun onResume() {
        super.onResume()
    }

    override fun onPause() {
        super.onPause()
    }



    private fun doReplaceFragment(loginStep: LoginStep) {
        val fragment = when (loginStep) {
            LoginStep.SINGIN -> loginFragment
            LoginStep.NEWUSER -> null
        }

        val transaction = supportFragmentManager.beginTransaction()
        if (fragment != null) {
            transaction.replace(R.id.fragments_holder_login, fragment)
        }
        transaction.commit()
    }
}
