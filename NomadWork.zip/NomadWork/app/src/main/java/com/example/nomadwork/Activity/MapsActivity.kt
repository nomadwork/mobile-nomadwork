package com.example.nomadwork.Activity

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Looper
import android.util.Log
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.example.nomadwork.Helpers.LocationHelper
import com.example.nomadwork.R
import com.google.android.gms.location.*
import com.google.android.gms.maps.*
import com.google.android.gms.maps.model.BitmapDescriptorFactory

import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions

class MapsActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var mMap: GoogleMap

    companion  object {
        const val TAG = "MapsActivity"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        checkPermissions()
        setContentView(R.layout.activity_maps)
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }

    override fun onResume() {
        super.onResume()
        startLocationUpdates()

        System.out.println(LocationHelper.getUserLocation()?.latitude)
    }

    override fun onPause() {
        super.onPause()
        stopLocationUpdates()
    }

    override fun onStop() {
        super.onStop()
    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */

    @SuppressLint("MissingPermission")
    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap


        //Add a marker in Sydney and move the camera
 //       val sydney = LatLng(-34.0, 151.0)
 //       mMap.addMarker(MarkerOptions().position(sydney).title("Marker in Sydney"))
 //       mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(sydney, 12.0f))
    }




    /**
     * Inicia o serviço de localização caso o App tenha permissão
     */
    private fun checkPermissions() {

        val writePermission = (ContextCompat.checkSelfPermission(applicationContext,
            Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)

        val locationPermission = (ContextCompat.checkSelfPermission(applicationContext,
            Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)

        val cameraPermission = (ContextCompat.checkSelfPermission(applicationContext,
            Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)


        val appPermissions = ArrayList<String>()
        appPermissions.add(Manifest.permission.BLUETOOTH_ADMIN)
        appPermissions.add(Manifest.permission.ACCESS_FINE_LOCATION)
        appPermissions.add(Manifest.permission.ACCESS_COARSE_LOCATION)
        appPermissions.add(Manifest.permission.CAMERA)
        appPermissions.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)

        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.M) {
            appPermissions.add(Manifest.permission.REQUEST_INSTALL_PACKAGES)
        }

        val permissions = arrayOfNulls<String>(appPermissions.size)
        appPermissions.toArray(permissions)

        if (!writePermission || !locationPermission || !cameraPermission) {
            ActivityCompat.requestPermissions(this, permissions, PackageManager.PERMISSION_GRANTED)
        }
        initLocation()
    }


    private var mFusedLocationProviderClient: FusedLocationProviderClient? = null
    private val INTERVAL: Long = 5 * 60 * 1000
    lateinit var mLocationRequest: LocationRequest


    private fun initLocation() {

        if (checkPermissionForLocation(this)) {
            // Create the location request to start receiving updates
            mLocationRequest = LocationRequest()
            mLocationRequest.priority = LocationRequest.PRIORITY_BALANCED_POWER_ACCURACY
            mLocationRequest.interval = INTERVAL
            mLocationRequest.fastestInterval = INTERVAL
            // Create LocationSettingsRequest object using location request
            val builder = LocationSettingsRequest.Builder()
            builder.addLocationRequest(mLocationRequest)
            val locationSettingsRequest = builder.build()

            val settingsClient = LocationServices.getSettingsClient(this)
            settingsClient.checkLocationSettings(locationSettingsRequest)
            mFusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this)

        }
    }

    private fun startLocationUpdates() {
        // new Google API SDK v11 uses getFusedLocationProviderClient(this)
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return
        }
        mFusedLocationProviderClient?.requestLocationUpdates(mLocationRequest, mLocationCallback, Looper.myLooper())
    }

    private val mLocationCallback = object : LocationCallback() {
        override fun onLocationResult(locationResult: LocationResult) {
            // do work here
            locationResult.lastLocation
            onLocationChanged(locationResult.lastLocation)

            Log.i(TAG, locationResult.lastLocation.longitude.toString() +","+locationResult.lastLocation.latitude.toString())

         }
    }

    fun onLocationChanged(location: Location) {
        // New location has now been determined
        LocationHelper.updateLocation(location)


        // Add a marker in Sydney and move the camera
        val sydney = LatLng(LocationHelper.getUserLocation()!!.latitude, LocationHelper.getUserLocation()!!.longitude)
        mMap.addMarker(MarkerOptions().position(sydney).title("Marker in Sydney").icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE)))
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(sydney, 15.0f))
    }

    private fun stopLocationUpdates() {
        mFusedLocationProviderClient?.removeLocationUpdates(mLocationCallback)
    }

    private fun checkPermissionForLocation(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {

            if (context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                true
            } else {
                // Show the permission request
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), PackageManager.PERMISSION_GRANTED)
                false
            }
        } else {
            true
        }
    }
}
