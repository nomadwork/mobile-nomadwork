package com.example.nomadwork.Fragments


import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.TextView
import butterknife.BindView
import butterknife.ButterKnife
import butterknife.OnClick

import com.example.nomadwork.R
import kotlinx.android.synthetic.main.fragment_login.*

class LoginFragment : Fragment() {

    @BindView(R.id.wrong_login_message) lateinit var messagesTextView: TextView
    @BindView(R.id.user_editText) lateinit var userEditText: EditText
    @BindView(R.id.password_editText) lateinit var passwordEditText: EditText
    @BindView(R.id.app_version) lateinit var appVersion: TextView

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val v = inflater.inflate(R.layout.fragment_login, container, false)
        ButterKnife.bind(this, v)

        return v
    }

    @OnClick(R.id.enter_button)
    fun nextStepLogin(){
        user_editText.visibility = View.GONE
        password_editText.visibility = View.VISIBLE
    }
}