package com.example.nomadwork.Helpers

import android.location.Location
import android.util.Log
import com.google.gson.annotations.SerializedName


object LocationHelper {
    private lateinit var lastLocation: Location

    fun updateLocation(location: Location) {
        this.lastLocation = location
        Log.i("Location", "Lat: ${location.latitude} Long: ${location.longitude}")

    }

    fun getUserLocation(): UserLocation? {
        if (this::lastLocation.isInitialized) {
            return UserLocation(lastLocation.latitude, lastLocation.longitude)
        }
        return null
    }
}

data class UserLocation(
    @SerializedName("lat") val latitude: Double,
    @SerializedName("lon") val longitude: Double
)